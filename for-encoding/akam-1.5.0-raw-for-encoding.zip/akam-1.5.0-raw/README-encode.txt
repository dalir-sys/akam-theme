فایل‌های خام قالب آکام نسخه 1.5.0 برای اینکد در راست‌چین (انکدر جدید)

هش لایسنس در functions.php: 578ac492d50af8e81e4307275311d3fac196fb9a

این ۱۷ فایل را با همین مسیرها اینکد کنید:
  functions.php  (تغییر کرده نسبت به 1.0.0)
  inc/compatibility/elementor.php  (تغییر کرده نسبت به 1.0.0)
  inc/contact-form.php
  inc/enqueue.php  (تغییر کرده نسبت به 1.0.0)
  inc/helpers.php
  inc/layout-conditions.php
  inc/layout-post-type.php
  inc/layout-renderer.php  (تغییر کرده نسبت به 1.0.0)
  inc/mega-menu.php
  inc/newsletter.php
  inc/otp-auth.php
  inc/setup.php
  inc/stories-post-type.php
  inc/support-tickets.php
  inc/teachers-post-type.php  (تغییر کرده نسبت به 1.0.0)
  inc/theme-options/admin-page.php  (تغییر کرده نسبت به 1.0.0)
  inc/theme-options/ajax-handler.php  (تغییر کرده نسبت به 1.0.0)

پوشه optional-new-files (اختیاری، پیشنهادی): فایل‌های جدید نسخه 1.5.0
  inc/video-embeds.php
  inc/ai-chat.php
  inc/visual-effects.php
