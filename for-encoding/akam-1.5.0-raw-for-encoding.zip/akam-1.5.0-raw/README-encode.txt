فایل‌های خام قالب آکام نسخه 1.5.0 برای اینکد در راست‌چین (انکدر جدید)

نسخه جدید: هش لایسنس در functions.php به 769a0be25c5d4a5d8ce0eaa46664fef59d815fc4 تغییر کرده است.
فایل RTL_License_1caedf22ac6ba764.php جدید (از راست‌چین) داخل قالب قرار گرفته و نیازی به اینکد ندارد.

این ۱۷ فایل را با همین مسیرها اینکد کنید:
  functions.php
  inc/compatibility/elementor.php
  inc/contact-form.php
  inc/enqueue.php
  inc/helpers.php
  inc/layout-conditions.php
  inc/layout-post-type.php
  inc/layout-renderer.php
  inc/mega-menu.php
  inc/newsletter.php
  inc/otp-auth.php
  inc/setup.php
  inc/stories-post-type.php
  inc/support-tickets.php
  inc/teachers-post-type.php
  inc/theme-options/admin-page.php
  inc/theme-options/ajax-handler.php

پوشه optional-new-files (اختیاری، پیشنهادی): فایل‌های جدید نسخه 1.5.0
  inc/video-embeds.php
  inc/ai-chat.php
  inc/visual-effects.php
